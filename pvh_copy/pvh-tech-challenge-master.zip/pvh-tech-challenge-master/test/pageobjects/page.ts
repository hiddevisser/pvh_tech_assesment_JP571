export default class Page {
	open() {
		return browser.url(`https://nl.tommy.com`);
	}
}
